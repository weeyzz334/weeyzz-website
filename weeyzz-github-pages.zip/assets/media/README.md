# Media logos

Candidate logos supplied in the Downloads folder:

- `le360.jpg` — Le360 mark
- `kassetta.jpg` — Kassetta mark
- `ht-radio.jfif` — HT Radio mark
- `snrt.jfif` — SNRT mark

The HT Radio and SNRT files were duplicated in the source `photo/` folder; identical copies were consolidated here. Background-transparent PNG versions of all four marks are used in the compact “As featured on” strip.
