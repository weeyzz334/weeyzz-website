# Artist logo

The supplied WEEYZZ logo was edited to remove its black background and is integrated in the navigation and footer as `weeyzz-logo-transparent.png`. The original source is kept as `weeyzz-logo.jfif`.
